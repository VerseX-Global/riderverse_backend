"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.riderDeliveryRouter = void 0;
// src/routes/userRoutes.ts
const express_1 = __importDefault(require("express"));
// import { acceptDelivery, pickDelivery, rejectDelivery, viewAllDelivery, viewSingleDelivery } from '../../controllers/RiderControllers/deliveryController';
exports.riderDeliveryRouter = express_1.default.Router();
// riderDeliveryRouter.get('/pickup-delivery', authenticateJWT, pickDelivery);
// riderDeliveryRouter.get('/all-delivery', authenticateJWT, viewAllDelivery);
// riderDeliveryRouter.get('/single-delivery', authenticateJWT, viewSingleDelivery);
// riderDeliveryRouter.put('/accept-delivery', authenticateJWT, acceptDelivery);
// riderDeliveryRouter.put('/reject-delivery', authenticateJWT, rejectDelivery);
